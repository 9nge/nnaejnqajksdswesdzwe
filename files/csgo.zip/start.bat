@echo off
chcp 65001
pip install tkinter
pip install pymem
pip install ctypes
echo Зависимости установлены, запускайте calculator.py
pause
import atexit
import ctypes
import json
import os
import re
import shutil
import signal
import struct
import subprocess
import sys
import threading
import time
from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass
from pathlib import Path

try:
    import tkinter as tk
except ImportError:
    tk = None

try:
    import pymem
    import pymem.process
    _PYMEM_OK = True
except ImportError:
    _PYMEM_OK = False


SECRET = "0402"
CONFIG_PATH = Path(__file__).resolve().with_name("calc_settings.json")

CONSOLE_COLS = 200
CONSOLE_LINES = 56
CONSOLE_W = 1600
CONSOLE_H = 900


def fix_console():
    if os.name != "nt":
        return
    try:
        os.system("chcp 65001 > nul")
    except Exception:
        pass
    try:
        ctypes.windll.kernel32.SetConsoleOutputCP(65001)
        ctypes.windll.kernel32.SetConsoleCP(65001)
    except Exception:
        pass
    try:
        os.system(f"mode con: cols={CONSOLE_COLS} lines={CONSOLE_LINES}")
    except Exception:
        pass
    try:
        from ctypes import wintypes
        k32 = ctypes.windll.kernel32
        u32 = ctypes.windll.user32

        hwnd = k32.GetConsoleWindow()
        h_out = k32.GetStdHandle(-11)

        try:
            k32.SetConsoleScreenBufferSize(h_out, wintypes._COORD(CONSOLE_COLS, CONSOLE_LINES))
        except Exception:
            pass

        if hwnd:
            rect = wintypes.RECT()
            u32.GetWindowRect(hwnd, ctypes.byref(rect))

            GWL_STYLE = -16
            WS_THICKFRAME = 0x00040000
            WS_MAXIMIZEBOX = 0x00010000

            style = u32.GetWindowLongW(hwnd, GWL_STYLE)
            style &= ~WS_THICKFRAME
            style &= ~WS_MAXIMIZEBOX
            u32.SetWindowLongW(hwnd, GWL_STYLE, style)

            u32.MoveWindow(hwnd, rect.left, rect.top, CONSOLE_W, CONSOLE_H, True)
    except Exception:
        pass


_user32 = ctypes.windll.user32 if os.name == "nt" else None

VK = {
    "Mouse1": 0x01, "Mouse2": 0x02, "Mouse3": 0x04,
    "Mouse4": 0x05, "Mouse5": 0x06,
    "Shift": 0x10, "Ctrl": 0x11, "Alt": 0x12, "Space": 0x20,
}


def key_down(name):
    if not _user32:
        return False
    vk = VK.get(name, 0)
    return bool(_user32.GetAsyncKeyState(vk) & 0x8000)


class Off:
    dwLocalPlayer       = 0xDEF97C
    dwEntityList        = 0x4E051DC
    dwForceJump         = 0x52C0F50

    m_iHealth               = 0x100
    m_iTeamNum              = 0xF4
    m_fFlags                = 0x104
    m_iShotsFired           = 0x103E0
    m_flFlashDuration       = 0x10470
    m_flFlashMaxAlpha       = 0x1046C
    m_bDormant              = 0xED
    m_lifeState             = 0x25F
    m_bSpotted              = 0x93D
    m_bSpottedByMask        = 0x980


@dataclass
class Vec3:
    x: float = 0.0
    y: float = 0.0
    z: float = 0.0


def scan_pattern(pm, base, size, pattern_str):
    parts = pattern_str.split()
    if not parts:
        return 0

    try:
        regex = b"".join(
            b"." if p == "??" else re.escape(bytes([int(p, 16)]))
            for p in parts
        )
        pat = re.compile(regex, re.DOTALL)
    except Exception:
        return 0

    overlap = len(parts) + 4
    chunk = 8 * 1024 * 1024
    offset = 0

    while offset < size:
        read_size = min(chunk, size - offset)
        try:
            data = pm.read_bytes(base + offset, read_size)
        except Exception:
            offset += 65536
            continue

        m = pat.search(data)
        if m:
            return base + offset + m.start()

        if read_size < chunk:
            break
        offset += read_size - overlap

    return 0


class Mem:
    def __init__(self):
        self.pm = pymem.Pymem("csgo.exe")
        client_mod = pymem.process.module_from_name(self.pm.process_handle, "client.dll")
        self.client = client_mod.lpBaseOfDll
        self.client_size = client_mod.SizeOfImage

    def ri32(self, a): return self.pm.read_int(a)
    def wi32(self, a, v): self.pm.write_int(a, v)
    def wf32(self, a, v): self.pm.write_float(a, v)
    def rb(self, a): return self.pm.read_uchar(a)
    def wb(self, a, v): self.pm.write_uchar(a, v)

    def local_player(self):
        return self.ri32(self.client + Off.dwLocalPlayer)

    def entity(self, idx):
        return self.ri32(self.client + Off.dwEntityList + idx * 0x10)

    def force_jump(self):
        return self.client + Off.dwForceJump

    def get_flags(self, e): return self.ri32(e + Off.m_fFlags)
    def get_health(self, e): return self.ri32(e + Off.m_iHealth)
    def get_team(self, e): return self.ri32(e + Off.m_iTeamNum)
    def is_dormant(self, e): return self.rb(e + Off.m_bDormant) != 0

    def is_alive(self, e):
        return self.rb(e + Off.m_lifeState) == 0 and self.get_health(e) > 0

    def set_flash(self, e, v):
        self.wf32(e + Off.m_flFlashMaxAlpha, v)
        self.wf32(e + Off.m_flFlashDuration, v)


FL_ONGROUND = 1 << 0
JUMP_NONE = 4
JUMP_HOLD = 6


class Wallhack:
    PATTERN = "33 C0 83 FA ?? B9 20"

    def __init__(self):
        self._addr = 0
        self._active = False

    def _find(self, mem):
        if self._addr:
            return self._addr
        addr = scan_pattern(mem.pm, mem.client, mem.client_size, self.PATTERN)
        if addr:
            self._addr = addr + 4
        return self._addr

    def tick(self, mem, cfg):
        enabled = bool(cfg.get("Wallhack", False))
        if not enabled and not self._active:
            return
        addr = self._find(mem)
        if not addr:
            return
        try:
            if enabled and not self._active:
                mem.wb(addr, 1)
                self._active = True
            elif not enabled and self._active:
                mem.wb(addr, 0)
                self._active = False
        except Exception:
            pass

    def clear(self, mem):
        if self._addr and self._active:
            try:
                mem.wb(self._addr, 0)
            except Exception:
                pass
        self._active = False


class Radar:
    def tick(self, mem, local, cfg):
        if not cfg.get("Radar", False):
            return
        try:
            my_team = mem.get_team(local)
            for i in range(1, 65):
                try:
                    ent = mem.entity(i)
                    if not ent or ent == local or not (0x10000 < ent < 0x80000000):
                        continue
                    if mem.is_dormant(ent) or not mem.is_alive(ent):
                        continue
                    if mem.get_team(ent) == my_team:
                        continue
                    mem.wb(ent + Off.m_bSpotted, 1)
                    mem.wb(ent + Off.m_bSpottedByMask, 1)
                except Exception:
                    pass
        except Exception:
            pass


def bhop_tick(mem, local):
    try:
        addr = mem.force_jump()
        if not key_down("Space"):
            mem.wi32(addr, JUMP_NONE)
            return
        if mem.get_flags(local) & FL_ONGROUND:
            mem.wi32(addr, JUMP_HOLD)
        else:
            mem.wi32(addr, JUMP_NONE)
    except Exception:
        pass


def no_flash_tick(mem, local):
    try:
        mem.set_flash(local, 0.0)
    except Exception:
        pass


class Engine:
    TICK = 1 / 128

    def __init__(self, config):
        self._cfg = config
        self._lock = threading.Lock()
        self._running = False
        self._thread = None
        self.mem = None
        self.error = ""
        self.status = "waiting"
        self._cleanup_done = False

        self._wall = Wallhack()
        self._radar = Radar()

        atexit.register(self._atexit_cleanup)
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                signal.signal(sig, self._signal_handler)
            except Exception:
                pass

    def _signal_handler(self, signum, frame):
        self.stop()
        raise SystemExit(0)

    def _atexit_cleanup(self):
        self.stop()

    def update_config(self, cfg):
        with self._lock:
            self._cfg = cfg

    def _cfg_get(self, module, key, default=False):
        with self._lock:
            return self._cfg.get(module, {}).get(key, default)

    def _module_dict(self, name):
        with self._lock:
            return dict(self._cfg.get(name, {}))

    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True, name="calc-engine")
        self._thread.start()

    def stop(self):
        if self._cleanup_done:
            return
        self._cleanup_done = True
        self._running = False
        try:
            if self.mem:
                try:
                    self._wall.clear(self.mem)
                except Exception:
                    pass
                try:
                    local = self.mem.local_player()
                    if local and 0x10000 < local < 0x80000000:
                        self.mem.set_flash(local, 0.0)
                        self.mem.wi32(local + Off.m_iShotsFired, 0)
                except Exception:
                    pass
                try:
                    self.mem.wi32(self.mem.force_jump(), JUMP_NONE)
                except Exception:
                    pass
        except Exception:
            pass

    def _loop(self):
        while self._running:
            if self.mem is None:
                try:
                    self.mem = Mem()
                    self.error = ""
                    self.status = "connected"
                except Exception as e:
                    self.error = f"{type(e).__name__}"
                    self.status = "waiting"
                    time.sleep(2)
                    continue

            m = self.mem
            t0 = time.perf_counter()
            try:
                local = m.local_player()
                if not local or not (0x10000 < local < 0x80000000):
                    self.status = "no map"
                    time.sleep(0.5)
                    continue

                self.status = "active"

                render_cfg = self._module_dict("Render")
                self._wall.tick(m, render_cfg)
                self._radar.tick(m, local, render_cfg)

                if self._cfg_get("Movement", "Bhop"):
                    bhop_tick(m, local)

                if render_cfg.get("No flash", False):
                    no_flash_tick(m, local)

            except Exception as e:
                self.error = f"{type(e).__name__}"
                self.status = "reconnecting"
                self.mem = None
                time.sleep(1)
                continue

            wait = self.TICK - (time.perf_counter() - t0)
            if wait > 0:
                time.sleep(wait)


BANNER = r"""
 ███▄    █   ██ ███▄    █ ▓█████      ██░ ██  ▄▄▄      ▄████▄  ▀██ ▄█▀
 ██ ▀█   █ ▒▓██ ██ ▀█   █ ▓█   ▀    ▒▓██░ ██ ▒████▄   ▒██▀ ▀█   ██▄█▒
▓██  ▀█ ██▒░▒██▓██  ▀█ ██▒▒███      ░▒██▀▀██ ▒██  ▀█▄ ▒▓█    ▄ ▓███▄░
▓██▒  ▐▌██▒ ░██▓██▒  ▐▌██▒▒▓█  ▄     ░▓█ ░██ ░██▄▄▄▄██▒▓▓▄ ▄██ ▓██ █▄
▒██░   ▓██░ ░██▒██░   ▓██░░▒████     ░▓█▒░██▓ ▓█   ▓██▒ ▓███▀  ▒██▒ █▄
░ ▒░   ▒ ▒  ░▓ ░ ▒░   ▒ ▒ ░░ ▒░       ▒ ░░▒░▒ ▒▒   ▓▒█░ ░▒ ▒   ▒ ▒▒ ▓▒
░ ░░   ░ ▒░  ▒ ░ ░░   ░ ▒░ ░ ░        ▒ ░▒░ ░  ░   ▒▒   ░  ▒   ░ ░▒ ▒░
   ░   ░ ░   ▒    ░   ░ ░    ░        ░  ░░ ░  ░   ▒  ░        ░ ░░ ░
         ░   ░          ░    ░        ░  ░  ░      ░  ░ ░      ░  ░
""".strip("\n").splitlines()

RST, BOLD = "\033[0m", "\033[1m"


def c(n):
    return f"\033[38;5;{n}m"


DIM, GREY, WHITE = c(240), c(250), c(255)

THEMES = {
    "Purple": (93, 99, 135, 171, 207, 213),
    "Red":    (52, 88, 124, 160, 196, 203),
    "Cyan":   (24, 31, 38, 45, 51, 87),
    "Green":  (22, 28, 34, 40, 46, 82),
    "Mono":   (238, 242, 246, 250, 252, 255),
}

COLORS = {
    "Red": 196, "Orange": 208, "Yellow": 226, "Green": 46,
    "Cyan": 51, "Blue": 33, "Purple": 135, "White": 255,
}


class Item:
    def __init__(self, label, kind, default=None, *, lo=0, hi=0, step=1, options=(), unit="", action=""):
        self.label, self.kind = label, kind
        self.default = self.value = default
        self.lo, self.hi, self.step = lo, hi, step
        self.options, self.unit, self.action = tuple(options), unit, action

    def adjust(self, d):
        if self.kind == "toggle":
            self.value = not self.value
        elif self.kind == "slider":
            self.value = round(min(self.hi, max(self.lo, self.value + d * self.step)), 3)
        elif self.kind in ("choice", "color"):
            i = self.options.index(self.value)
            self.value = self.options[(i + d) % len(self.options)]

    def reset(self):
        if self.kind != "button":
            self.value = self.default

    def set(self, v):
        if self.kind == "toggle" and isinstance(v, bool):
            self.value = v
        elif self.kind == "slider" and isinstance(v, (int, float)) and not isinstance(v, bool):
            self.value = min(self.hi, max(self.lo, v))
        elif self.kind in ("choice", "color") and isinstance(v, str) and v in self.options:
            self.value = v

    def display(self, accent):
        if self.kind == "toggle":
            return f"{c(accent)}●{RST} {WHITE}ON{RST}" if self.value else f"{DIM}○ OFF{RST}"
        if self.kind == "slider":
            w = 12
            pos = round((self.value - self.lo) / ((self.hi - self.lo) or 1) * (w - 1))
            bar = f"{c(accent)}{'━' * pos}{WHITE}●{DIM}{'─' * (w - 1 - pos)}{RST}"
            return f"{bar} {GREY}{self.value:g}{self.unit}{RST}"
        if self.kind == "choice":
            return f"{DIM}‹{RST} {GREY}{self.value}{RST} {DIM}›{RST}"
        if self.kind == "color":
            return f"{c(COLORS[self.value])}■{RST} {GREY}{self.value}{RST}"
        return ""


def T(label, default=False):
    return Item(label, "toggle", default)


def C(label, options, default=None):
    return Item(label, "choice", default or options[0], options=options)


def B(label, action):
    return Item(label, "button", action=action)


class Module:
    def __init__(self, name, items):
        self.name, self.items = name, items

    def get(self, label):
        return next(i for i in self.items if i.label == label)

    @property
    def master(self):
        return next((i for i in self.items if i.label == "Enabled"), None)


def build_modules():
    return [
        Module("Render", [
            T("Wallhack", False),
            T("Radar", False),
            T("No flash", False),
        ]),
        Module("Movement", [
            T("Bhop", False),
        ]),
    ]


WASD = {"w": "up", "s": "down", "a": "left", "d": "right", " ": "enter"}
ARROWS = {"H": "up", "P": "down", "K": "left", "M": "right"}
PENDING = deque()
CSI = {b"[A": "up", b"[B": "down", b"[C": "right", b"[D": "left",
       b"OA": "up", b"OB": "down", b"OC": "right", b"OD": "left"}


def read_key():
    if os.name == "nt":
        import msvcrt
        ch = msvcrt.getwch()
        if ch in ("\x00", "\xe0"):
            return ARROWS.get(msvcrt.getwch(), "")
        if ch == "\r":
            return "enter"
        if ch in ("\x1b", "\x08"):
            return "esc"
        if ch == "\x03":
            return "quit"
        return WASD.get(ch.lower(), ch.lower())

    if not PENDING:
        data = os.read(sys.stdin.fileno(), 64)
        if not data:
            return "quit"
        keys, i, n = [], 0, len(data)
        while i < n:
            b = data[i:i + 1]
            if b == b"\x1b":
                if i + 1 >= n:
                    keys.append("esc")
                    i += 1
                elif data[i + 1:i + 2] in (b"[", b"O"):
                    j = i + 2
                    while j < n and not 0x40 <= data[j] <= 0x7E:
                        j += 1
                    keys.append(CSI.get(data[i + 1:i + 3], "") if j == i + 2 else "")
                    i = j + 1
                else:
                    i += 2
            elif b in (b"\r", b"\n"):
                keys.append("enter")
                i += 1
            elif b in (b"\x7f", b"\x08"):
                keys.append("esc")
                i += 1
            elif b == b"\x03":
                keys.append("quit")
                i += 1
            else:
                j = i + 1
                while j < n and (data[j] & 0xC0) == 0x80:
                    j += 1
                ch = data[i:j].decode("utf-8", "ignore").lower()
                keys.append(WASD.get(ch, ch))
                i = j
        PENDING.extend(k for k in keys if k)
    return PENDING.popleft() if PENDING else ""


@contextmanager
def terminal():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass

    state = fd = None
    if os.name == "nt":
        try:
            k32 = ctypes.windll.kernel32
            handle = k32.GetStdHandle(-11)
            mode = ctypes.c_ulong()
            k32.GetConsoleMode(handle, ctypes.byref(mode))
            k32.SetConsoleMode(handle, mode.value | 0x0004)
        except Exception:
            pass
    else:
        import termios
        import tty
        fd = sys.stdin.fileno()
        state = termios.tcgetattr(fd)
        tty.setcbreak(fd)

    sys.stdout.write("\033[?1049h\033[?25l\033]0;calc\007\033[2J\033[H")
    sys.stdout.flush()

    fix_console()

    try:
        yield
    finally:
        sys.stdout.write(f"{RST}\033[?25h\033[?1049l")
        sys.stdout.flush()
        if state is not None:
            import termios
            termios.tcsetattr(fd, termios.TCSADRAIN, state)


STATUS_STYLES = {
    "active":        (46,  "●", "csgo подключен"),
    "no map":        (226, "◐", "ждём загрузку карты"),
    "connected":     (226, "◐", "подключено, ждём карту"),
    "reconnecting":  (196, "◑", "переподключение..."),
    "waiting":       (240, "○", "ждём csgo.exe"),
}


class MenuApp:
    def __init__(self):
        self.config = Module("Config", [
            C("Theme", list(THEMES)),
            B("Save config", "save"),
            B("Load config", "load"),
            B("Reset all", "reset"),
        ])
        self.pages = build_modules() + [self.config]
        self.page = None
        self.cur = 0
        self.icur = 0
        self.msg = ""

        self.engine = None
        if _PYMEM_OK:
            self.engine = Engine(self._engine_cfg())
            self.engine.start()

    def _engine_cfg(self):
        cfg = {}
        for m in self.pages:
            if m.name in ("Render", "Movement"):
                cfg[m.name] = {i.label: i.value for i in m.items if i.kind != "button"}
        return cfg

    @property
    def grad(self):
        return THEMES[self.config.get("Theme").value]

    @property
    def accent(self):
        return self.grad[4]

    def save(self):
        data = {}
        for m in self.pages:
            data[m.name] = {i.label: i.value for i in m.items if i.kind != "button"}
        try:
            CONFIG_PATH.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
            return True
        except OSError:
            return False

    def load(self):
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return False
        if not isinstance(data, dict):
            return False
        for m in self.pages:
            saved = data.get(m.name)
            if isinstance(saved, dict):
                for i in m.items:
                    if i.label in saved:
                        i.set(saved[i.label])
        return True

    def act(self, action):
        if action == "save":
            self.msg = "Config saved" if self.save() else "Save failed"
        elif action == "load":
            self.msg = "Config loaded" if self.load() else "No config found"
        elif action == "reset":
            for m in self.pages:
                for i in m.items:
                    i.reset()
            self.msg = "Settings reset"

    def _status_line(self):
        if not _PYMEM_OK:
            return f"{c(196)}✗ {GREY}pymem не установлен{RST}"
        if self.engine:
            st = self.engine.status
            color, icon, text = STATUS_STYLES.get(st, (240, "○", st))
            return f"{c(color)}{icon} {GREY}{text}{RST}"
        return ""

    def _menu_lines(self):
        g, n = self.grad, len(BANNER)
        header = [""] + [f"{c(g[i * len(g) // n])}{line}{RST}" for i, line in enumerate(BANNER)] + [""]

        a = self.accent
        body = []

        if self.page is None:
            npages = len(self.pages)
            body.append(f"   {DIM}modules{RST}")
            body.append("")
            for i in range(npages + 1):
                sel = self.cur == i
                name = self.pages[i].name if i < npages else "Exit"
                num = str(i + 1) if i < npages else "0"
                m = self.pages[i].master if i < npages else None
                dot = ""
                if m is not None:
                    dot = f" {c(a)}●{RST}" if m.value else f" {DIM}○{RST}"
                cur = f"{c(a)}›{RST}" if sel else " "
                style = BOLD + WHITE if sel else GREY
                body.append(f"   {cur} {DIM}{num}{RST}  {style}{name:<14}{RST}{dot}")
            body.append("")
            body.append(f"   {DIM}↑↓ select   enter open   1-{npages}{RST}")
        else:
            body.append(f"   {BOLD}{c(a)}{self.page.name}{RST}")
            body.append("")
            for idx, it in enumerate(self.page.items):
                sel = self.icur == idx
                cur = f"{c(a)}›{RST}" if sel else " "
                if it.kind == "button":
                    body.append(f"   {cur} {c(a) if sel else GREY}{it.label}{RST}")
                else:
                    style = BOLD + WHITE if sel else GREY
                    body.append(f"   {cur} {style}{it.label:<16}{RST}{it.display(a)}")
            body.append("")
            body.append(f"   {DIM}↑↓ move   ←→ change   esc back{RST}")

        if self.msg:
            body.append(f"   {c(a)}✓ {self.msg}{RST}")

        return header + body

    def frame(self):
        return self._menu_lines()

    def render(self):
        lines = self.frame()
        out = "\033[H"
        for ln in lines:
            out += ln + "\033[K\n"
        out += "\033[J"

        status = self._status_line()
        if status:
            row = CONSOLE_LINES - 1
            col = 4
            out += f"\033[{row};{col}H\033[K{status}"

        sys.stdout.write(out)
        sys.stdout.flush()

    def handle(self, key):
        self.msg = ""
        if key == "quit":
            return False

        if self.page is None:
            n = len(self.pages)
            if key == "up":
                self.cur = (self.cur - 1) % (n + 1)
            elif key == "down":
                self.cur = (self.cur + 1) % (n + 1)
            elif key in ("enter", "right"):
                if self.cur == n:
                    return False
                self.page, self.icur = self.pages[self.cur], 0
            elif key.isdecimal():
                d = int(key)
                if d == 0:
                    return False
                if 1 <= d <= n:
                    self.cur = d - 1
                    self.page, self.icur = self.pages[self.cur], 0
            elif key in ("esc", "q"):
                return False
            return True

        items = self.page.items
        it = items[self.icur]
        if key == "up":
            self.icur = (self.icur - 1) % len(items)
        elif key == "down":
            self.icur = (self.icur + 1) % len(items)
        elif key in ("left", "right") and it.kind != "button":
            it.adjust(-1 if key == "left" else 1)
        elif key == "enter":
            if it.kind == "button":
                self.act(it.action)
            else:
                it.adjust(1)
        elif key in ("esc", "q"):
            self.page = None
        return True

    def run(self):
        try:
            while True:
                self.render()
                if not self.handle(read_key()):
                    break
                if self.engine:
                    self.engine.update_config(self._engine_cfg())
        except (KeyboardInterrupt, SystemExit):
            pass
        except Exception:
            pass
        finally:
            if self.engine:
                try:
                    self.engine.stop()
                except Exception:
                    pass


def run_menu():
    app = MenuApp()
    try:
        with terminal():
            app.run()
    except (KeyboardInterrupt, SystemExit):
        pass
    except Exception:
        pass
    finally:
        if app.engine:
            try:
                app.engine.stop()
            except Exception:
                pass


class Calculator:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("Calculator")
        self.root.configure(bg="#1f1f1f")
        self.root.resizable(False, False)
        self.root.geometry("320x500")

        self.var = tk.StringVar(value="0")
        self.expr = ""
        self.proc = None

        self._build()
        self.root.bind("<Key>", self._on_key)
        self.root.focus_set()

    def _build(self):
        top = tk.Frame(self.root, bg="#1f1f1f")
        top.pack(fill="x", padx=8, pady=(12, 6))

        tk.Label(
            top, text="Standard",
            bg="#1f1f1f", fg="#aaa",
            font=("Segoe UI", 11),
            anchor="w",
        ).pack(fill="x")

        tk.Label(
            self.root, textvariable=self.var,
            bg="#1f1f1f", fg="#fff",
            font=("Segoe UI", 32, "bold"),
            anchor="e", padx=16, pady=12,
        ).pack(fill="x")

        grid = tk.Frame(self.root, bg="#1f1f1f")
        grid.pack(fill="both", expand=True, padx=6, pady=6)

        layout = [
            ("%", 0, 0, "#333"), ("CE", 0, 1, "#333"),
            ("C", 0, 2, "#333"), ("\u232b", 0, 3, "#333"),
            ("1/x", 1, 0, "#333"), ("x\u00b2", 1, 1, "#333"),
            ("\u221ax", 1, 2, "#333"), ("\u00f7", 1, 3, "#333"),
            ("7", 2, 0, "#2a2a2a"), ("8", 2, 1, "#2a2a2a"),
            ("9", 2, 2, "#2a2a2a"), ("\u00d7", 2, 3, "#333"),
            ("4", 3, 0, "#2a2a2a"), ("5", 3, 1, "#2a2a2a"),
            ("6", 3, 2, "#2a2a2a"), ("-", 3, 3, "#333"),
            ("1", 4, 0, "#2a2a2a"), ("2", 4, 1, "#2a2a2a"),
            ("3", 4, 2, "#2a2a2a"), ("+", 4, 3, "#333"),
            ("\u00b1", 5, 0, "#2a2a2a"), ("0", 5, 1, "#2a2a2a"),
            (".", 5, 2, "#2a2a2a"), ("=", 5, 3, "#0067c0"),
        ]

        for text, r, col, bg in layout:
            b = tk.Button(
                grid, text=text,
                bg=bg, fg="#fff",
                font=("Segoe UI", 13),
                bd=0, relief="flat",
                activebackground="#444",
                activeforeground="#fff",
                command=lambda t=text: self.on(t),
            )
            b.grid(row=r, column=col, sticky="nsew", padx=2, pady=2)

        for i in range(4):
            grid.grid_columnconfigure(i, weight=1)
        for i in range(6):
            grid.grid_rowconfigure(i, weight=1)

    def _on_key(self, event):
        ks = event.keysym
        ch = event.char

        if ks in ("Return", "KP_Enter"):
            self.on("=")
        elif ks == "BackSpace":
            self.on("\u232b")
        elif ks == "Escape":
            self.on("C")
        elif ks == "Delete":
            self.on("CE")
        elif ch in "0123456789.":
            self.on(ch)
        elif ch == "+":
            self.on("+")
        elif ch == "-":
            self.on("-")
        elif ch == "*":
            self.on("\u00d7")
        elif ch == "/":
            self.on("\u00f7")
        elif ch == "%":
            self.on("%")

    def on(self, key):
        if key in ("C", "CE"):
            self.expr = ""
            self.var.set("0")
            return

        if key == "\u232b":
            self.expr = self.expr[:-1]
            self.var.set(self.expr or "0")
            return

        if key == "\u00b1":
            self.expr = self.expr[1:] if self.expr.startswith("-") else "-" + self.expr
            self.var.set(self.expr or "0")
            return

        if key == "=":
            if self.expr == SECRET:
                self._launch()
                return
            try:
                expr = self.expr.replace("\u00d7", "*").replace("\u00f7", "/")
                result = eval(expr, {"__builtins__": {}}, {})
                if isinstance(result, float) and result.is_integer():
                    result = int(result)
                self.expr = str(result)
                self.var.set(self.expr)
            except Exception:
                self.var.set("Error")
                self.expr = ""
            return

        if key in ("%", "1/x", "x\u00b2", "\u221ax"):
            return

        self.expr += key
        self.var.set(self.expr)

    def _launch(self):
        self.expr = ""
        self.var.set("0")
        self.root.withdraw()

        flags = 0
        if os.name == "nt":
            flags = subprocess.CREATE_NEW_CONSOLE

        try:
            self.proc = subprocess.Popen(
                [sys.executable, str(Path(__file__).resolve()), "--menu"],
                creationflags=flags,
                cwd=str(Path(__file__).resolve().parent),
            )
            self.root.after(500, self._watch)
        except Exception:
            self.root.deiconify()

    def _watch(self):
        if self.proc and self.proc.poll() is None:
            self.root.after(500, self._watch)
        else:
            self.proc = None
            self.root.deiconify()

    def run(self):
        self.root.mainloop()


def main():
    if "--menu" in sys.argv:
        run_menu()
        return

    if tk is None:
        sys.stderr.write("tkinter не установлен\n")
        sys.exit(1)

    calc = Calculator()
    calc.run()


if __name__ == "__main__":
    main()